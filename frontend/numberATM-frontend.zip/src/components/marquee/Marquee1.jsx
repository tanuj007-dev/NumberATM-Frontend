import React from 'react'
import "./marquee1.css";

function Marquee1() {
    return (
        < div className = "bg-[#17565D] py-2 z-10 overflow-hidden whitespace-nowrap" >
            <div className="marquee1">
                <div className="marquee-content1">
                    <p className="text-[#FBBF24] text-xs sm:text-xl font-semibold mx-8">
                        100% Money-Back Guarantee - Full refund if you don’t receive your UPC!
                    </p>
                    <p className="text-[#FBBF24] text-xs sm:text-xl font-semibold mx-8">
                        Fast Delivery - Get your UPCs instantly after purchase.
                    </p>
                    <p className="text-[#FBBF24] text-xs sm:text-xl font-semibold mx-8">
                        Trusted by 10,000+ sellers across platforms.
                    </p>
                    <p className="text-[#FBBF24] text-xs sm:text-xl font-semibold mx-8">
                        100% Money-Back Guarantee - Full refund if you don’t receive your UPC!
                    </p>
                    <p className="text-[#FBBF24] text-xs sm:text-xl font-semibold mx-8">
                        Fast Delivery - Get your UPCs instantly after purchase.
                    </p>
                    <p className="text-[#FBBF24] text-xs sm:text-xl font-semibold mx-8">
                        Trusted by 10,000+ sellers across platforms.
                    </p>
                    <p className="text-[#FBBF24] text-xs sm:text-xl font-semibold mx-8">
                        100% Money-Back Guarantee - Full refund if you don’t receive your UPC!
                    </p>
                    <p className="text-[#FBBF24] text-xs sm:text-xl font-semibold mx-8">
                        Fast Delivery - Get your UPCs instantly after purchase.
                    </p>
                    <p className="text-[#FBBF24] text-xs sm:text-xl font-semibold mx-8">
                        Trusted by 10,000+ sellers across platforms.
                    </p>
                    <p className=" text-[#FBBF24] text-xs sm:text-xl font-semibold mx-8">
                        100% Money-Back Guarantee - Full refund if you don’t receive your UPC!
                    </p>
                    <p className="text-[#FBBF24] text-xs sm:text-xl font-semibold mx-8">
                        Fast Delivery - Get your UPCs instantly after purchase.
                    </p>
                    <p className="text-[#FBBF24] text-xs sm:text-xl font-semibold mx-8">
                        Trusted by 10,000+ sellers across platforms.
                    </p>
                    {/* Repeat if needed for continuous scroll */}
                </div>
            </div>
      </div >
  )
}

export default Marquee1
