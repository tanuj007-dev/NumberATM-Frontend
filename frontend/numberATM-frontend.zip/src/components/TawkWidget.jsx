import React from 'react'
import TawkMessengerReact from '@tawk.to/tawk-messenger-react';
export default function TawkWidget() {
  return (
    <div><TawkMessengerReact
                propertyId="653a47b1a84dd54dc48571e1"
                widgetId="1hdlqg3l6"/></div>
  )
}
