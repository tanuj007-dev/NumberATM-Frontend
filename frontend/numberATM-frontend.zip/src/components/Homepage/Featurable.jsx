// import {ElfsightWidget} from 'react-elfsight-widget'
export default function Featurable() {
  return (
    <div className='py-12 relative'>
        <h2 className="text-center text-2xl font-bold text-gray-800 mb-6">
        {/* <span className="text-blue-500">Google</span> Review */}
        Reviews
      </h2>
        {/* <ElfsightWidget widgetId='85a4dead-5516-411b-a245-7ecb99960cdf'/> */}
        <div className='bg-white absolute bottom-7 text-white max-w-[99vw] py-4 w-full z-50'>Ha</div>
    </div>
  )
}
